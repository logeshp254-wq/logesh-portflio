# Logesh Pandi V – Portfolio

## Run in VS Code
1. Open VS Code → File → Open Folder → choose this `portfolio` folder.
2. Install the recommended extension **Live Server** (VS Code will prompt you).
3. Right-click `index.html` → **Open with Live Server**.

## Structure
- `index.html`      – page content
- `css/style.css`   – all styling
- `js/script.js`    – menu, case-study popups, form, animations
- `images/logesh.jpg` – your portrait (replace to change photo)
- `resume.pdf`      – ADD your resume here (name must match)

## Replace before publishing
- `YOUR_EMAIL@example.com`, `[YOUR PHONE]`, `YOUR-LINKEDIN`, `91XXXXXXXXXX` (WhatsApp)
- Certificate image + `[YEAR]` + verify link
- `YOUR_FORM_ID` in the contact form (create a free form at formspree.io)
- `https://www.example.com/` in `<head>` (canonical / schema) once you have a domain
- Use Ctrl+Shift+F (search all files) to find every placeholder
